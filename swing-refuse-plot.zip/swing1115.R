#Swing 2011-2015
#Angela Kothe
#06.25.2021

library(devtools)
library(mapcan)
library(tidyverse)
library(socviz)
library(scales)
library(cowplot)
library(grid)
library(gridExtra)
library(dplyr)
library(extrafont)

font_import()

setwd("~/Desktop/r/swing")

#data
e2011 <- read_csv(file="2011.csv")
e2015 <- read_csv(file="2015.csv")

map <- mapcan(boundaries = ridings, type = standard)

#cleaning
e2011$riding_code <- e2011$`Electoral District Number`
e2011$votes11 <- e2011$`Votes Obtained`
e2011$pctvote11 <- e2011$`Percentage of Votes Obtained`
e2011$candidate11 <- e2011$Candidate

e2015$riding_code <- e2015$`Electoral District Number/Numéro de circonscription`
e2015$votes15 <- e2015$`Votes Obtained/Votes obtenus`
e2015$pctvote15 <- e2015$`Percentage of Votes Obtained /Pourcentage des votes obtenus`
e2015$candidate15 <- e2015$`Candidate/Candidat`

e2011 <- subset(e2011, select=c(riding_code, candidate11, votes11, pctvote11))
e2015 <- subset(e2015, select=c(riding_code, candidate15, votes15, pctvote15))

#swing data
swing <- full_join(e2011, e2015, by = "riding_code")

swing <- swing %>% filter(grepl('Liberal', candidate11))
swing <- swing %>% filter(grepl('Liberal', candidate15))

swing$swing <- swing$pctvote15 - swing$pctvote11

#map, don't forget to adjust legend size uni2
smap <- full_join(map, swing, by = "riding_code")

ggplot(map, aes(long, lat, group = group, fill = swing)) +
  geom_polygon(color = alpha("black", 1), size = 0.1) +
  scale_fill_gradient2(low = "blue", mid = "white", high = "red", 
                       midpoint=0, limits=c(-45, 45),
                       labels = c("45 Percent", "30 Percent", "15 Percent", "No Change", 
                                  "-15 Percent", "-30 Percent", "-45 Percent"),
                       breaks = c(45, 30, 15, 0, 
                                  -15, -30, -45))+
  theme_mapcan() +
  theme(text = element_text(size=12, family = "Georgia")) +
  theme(legend.title=element_blank()) +
  coord_fixed() +
  theme(legend.position = "right") +
  labs(title = "Liberal Vote Swing from 2011 to 2015",
       subtitle = "source: Elections Canada")

#to
#kitchener
#


#2011 Election Map
r2011 <- mapcan::federal_election_results %>%
  filter(election_year == 2011)

m2011 <- inner_join(map, r2011, by = "riding_code")

  ggplot(m2011, aes(x = long, y = lat, group = group, fill = party)) +
  geom_polygon() +
  coord_fixed() +
  theme_mapcan() +
  ggtitle("2011 Federal Electoral Results") +
  scale_fill_manual(name = "Winning party",
                    values = c("blue", "springgreen3", "red", "Orange")) 

#2015 Election Map
r2015 <- mapcan::federal_election_results %>%
    filter(election_year == 2015)
  
m2015 <- inner_join(map, r2015, by = "riding_code")
  
ggplot(m2015, aes(x = long, y = lat, group = group, fill = party)) +
    geom_polygon() +
    coord_fixed() +
    theme_mapcan() +
    ggtitle("2011 Federal Electoral Results") +
    scale_fill_manual(name = "Winning party",
                      values = c("blue", "springgreen3", "red", "Orange")) 
